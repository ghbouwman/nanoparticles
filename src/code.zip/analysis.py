import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from settings import *

def analyse(run_name):

    df = pd.read_csv(f"../output/{run_name}.csv")

    cut = 0
    T = df["Time (s)"][cut:]
    I = np.abs(df["Current (A)"])[cut:]
    I = running_mode(I)

    G = I / BIAS
    N = G / CONDUCTANCE_QUANTUM

    plt.xlabel("Time (ms)")
    plt.ylabel("Conductance ($G_0$)")
    # plt.yscale('log')
    plt.tight_layout()

    plt.scatter(1e3*T, N, s=2)
    plt.savefig(f"../output/{run_name}_current.png")
    plt.close()

def smooth(array):
    ones = np.ones(n)
    return np.convolve(array, ones, 'same')

def running_mode(array, n=1):

    modes = np.empty_like(array)

    for index in range(array.size):
        mode, count = stats.mode(array[index-n:index+n+1])
        if index < n or index+n > array.size-1 or count <= 2:
            mode = None
        modes[index] = mode

    return modes

