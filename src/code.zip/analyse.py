#!/usr/bin/env python

from analysis import analyse

for i in range(1, 10):
    analyse(f"run{i}")
